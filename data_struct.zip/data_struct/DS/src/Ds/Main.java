package Ds;
import java.io.File;
import java.util.*;

@SuppressWarnings("unused")
public class Main {
    public static Scanner input = new Scanner (System.in);
    /**
     *
     */
    public static Search_Engine searchEngine = new Search_Engine();
 
    

    //1

    public static int displayMenu() {
        System.out.println("\n=================== Welcome to Search Engine ===================");
        System.out.println("1. Term Retrieval.");
        System.out.println("2. Boolean Retrieval.");
        System.out.println("3. Ranked Retrieval.");
        System.out.println("4. Indexed Documents.");
        System.out.println("5. Indexed Tokens.");
        System.out.println("6. Exit.");
        System.out.println("================================================================");
        System.out.print("Please enter your choice: ");
        int choice = input.nextInt();
        input.nextLine(); // Consume newline left-over
        return choice;
    }
//2 
    public static void printBoolean(boolean[] result) {
        for (int i = 0; i < result.length; i++) {
            if (result[i]) {
                System.out.print("Document " + i + " ");
            }
        }
        System.out.println();
    }


    //3 
    
    public static void Retrieval_Term() {
        System.out.println("################### Retrieval Term ####################");

        System.out.println("1. Index");
        System.out.println("2. Inverted Index");
        System.out.println("3. Inverted Index using BST");
        System.out.println("4. Inverted Index using AVL");
        System.out.println("Enter your choice:");
        int choice1 = input.nextInt();

        System.out.println("Enter Term:");
        String str = input.next();

        System.out.print("Result doc IDs: ");
        printBoolean(searchEngine.Boolean_Retrieval(str.trim().toLowerCase(), choice1));
        System.out.println("\n");
    }


    //4 
    public static void Boolean_Retrieval_menu() {
        System.out.println("################### Boolean Retrieval ####################");
        System.out.println("1. Index");
        System.out.println("2. Inverted Index");
        System.out.println("3. Inverted Index using BST");
        System.out.println("4. Inverted Index using AVL");
        System.out.println("Enter your choice:");
        int choice1 = input.nextInt();

        System.out.println("Enter boolean term (AND/OR):");
        input.nextLine(); // Consume newline
        String str = input.nextLine();

        System.out.print("Q#: ");
        System.out.println(str);

        System.out.print("Result doc IDs: ");
        printBoolean(searchEngine.Boolean_Retrieval(str.trim().toUpperCase(), choice1));
        System.out.println("\n");
    }

//5 
public static void Ranked_Retrieval_menu() {
    System.out.println("######## Ranked Retrieval ######## ");
    System.out.println("1. Index");
    System.out.println("2. Inverted Index");
    System.out.println("3. Inverted Index using BST");
    System.out.println("4. Inverted Index using AVL");
    System.out.println("Enter your choice:");
    int choice1 = input.nextInt();

    System.out.print("Enter term: ");
    input.nextLine(); // Consume newline
    String str = input.nextLine();

    System.out.println("## Q: " + str);
    System.out.println("DocID\t  Score");
    switch (choice1) {
        case 1:
            System.out.println("Get ranked from index list");
            searchEngine.Ranked_Index(str);
            break;
        case 2:
            System.out.println("Get ranked from inverted index list");
            searchEngine.Ranked_RetrievalInvertedIndex(str);
            break;
        case 3:
            System.out.println("Get ranked from BST");
            searchEngine.Ranked_RetrievalBST(str);
            break;
        case 4:
            System.out.println("Get ranked from AVL");
            searchEngine.Ranked_RetrievalAVL(str);
            break;
    }
    System.out.println("\n");
}

//6
public static void Indexed_Documents_menu() {
    System.out.println("######## Indexed Documents ######## ");
    System.out.println("Indexed Documents");
    searchEngine.Indexed_Documents();
    System.out.println("");
}

//7 
 public static void Indexed_Tokens_menu() {
    System.out.println("######## Indexed Tokens ######## ");
    System.out.println("Tokens");
    searchEngine.Indexed_Tokens();
    System.out.println("");
}



//8
/**
 * @param args
 */
public static void main(String[] args) {
    String stopFile = "C:\\Users\\hp\\Desktop\\final project\\data_struct\\DS\\src\\Ds\\data\\stop.txt";
String datasetFile = "C:\\Users\\hp\\Desktop\\final project\\data_struct\\DS\\src\\Ds\\data\\dataset.csv";


searchEngine.LoadData(stopFile, datasetFile);

int choice;

    do {
        choice = displayMenu();
        switch (choice) {
            case 1:
                Retrieval_Term();
                break;
            case 2:
                Boolean_Retrieval_menu();
                break;
            case 3:
                Ranked_Retrieval_menu();
                break;
            case 4:
                Indexed_Documents_menu();
                break;
            case 5:
                Indexed_Tokens_menu();
                break;
            case 6:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Bad choice, try again!");
        }
    } while (choice != 6);
}



}
