package Ds;
public class Keyword {
    String term; 
    int[] documentFlags; // Stores the frequency of the term in each document

    // Default constructor
    public Keyword() {
        documentFlags = new int[50]; // Initialize the array for 50 documents
        for (int i = 0; i < documentFlags.length; i++) {
            documentFlags[i] = 0; // Initialize all frequencies to 0
        }
        term = ""; // Initialize with an empty term
    }

    // Parameterized constructor
    public Keyword(String term, int[] documentFlags) {
        this.term = term;
        this.documentFlags = new int[documentFlags.length];
        for (int i = 0; i < documentFlags.length; i++) {
            this.documentFlags[i] = documentFlags[i]; // Copy the array values
        }
    }

    // Adds a document ID to the list and increments the frequency for that document
    public void addDocument(int documentID) {
       
            this.documentFlags[documentID]++;
         
    }

    public void setTerm(String term) {
        this.term = term;
    }
    // Retrieves the keyword
    public String getTerm() {
        return term;
    }

    // Retrieves a copy of the document flags as boolean (indicating presence of the term)
    public int[] getDocumentFlags() {
        int [] test = new int[documentFlags.length];
        for (int i = 0; i < test.length; i++) 
        test[i] =documentFlags[i]; // Convert frequencies to boolean presence
        
        return test;
    }

    // Retrieves a copy of the document frequencies
    public int[] getDocs() {
        int[] documentFlagsCopy = new int[documentFlags.length];
        for (int i = 0; i < documentFlags.length; i++) {
            documentFlagsCopy[i] = documentFlags[i]; // Copy the array values
        }
        return documentFlagsCopy;
    }

    // Override toString method to display the term and its associated document IDs
    @Override
    public String toString() {
        StringBuilder docs = new StringBuilder();
        for (int i = 0, j = 0; i < documentFlags.length; i++) {
            if (documentFlags[i] > 0) { // Only include documents where the term appears
                if (j == 0) {
                    docs.append(" ").append(i);
                } else {
                    docs.append(", ").append(i);
                }
                j++;
            }
        }
        return term + "[" + docs + ']';
    }
}
