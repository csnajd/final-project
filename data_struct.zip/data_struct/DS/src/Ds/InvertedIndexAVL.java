package Ds;
public class InvertedIndexAVL {

    AVLTree<String, TermTF> invertedIndexAVL; // AVL Tree to store terms and their corresponding IndexTerm objects

    // Constructor
    public InvertedIndexAVL() {
        invertedIndexAVL = new AVLTree<String, TermTF>();
    }

    // Get the size of the inverted index
    public int size() {
        return invertedIndexAVL.size();
    }

    // Add a new term or update an existing term in the AVL Tree
    public boolean addNew(int docID, String word) {
        word = word.toLowerCase().trim(); // Normalize the word
        if (invertedIndexAVL.empty()) {
            TermTF term = new TermTF();
            term.setWord(word);
            term.addDocID(docID);
            invertedIndexAVL.insert(word, term);
           
            return true;
        } else {
            if (invertedIndexAVL.find(word)) {
                TermTF existingTerm = invertedIndexAVL.retrieve();
                existingTerm.addDocID(docID);
                invertedIndexAVL.update(existingTerm);
               
            }

            TermTF term = new TermTF();
            term.setWord(word);
            term.addDocID(docID);
            invertedIndexAVL.insert(word, term);
            
            return true;
        }
    }

    // Check if a term exists in the AVL Tree
    public boolean found(String word) {
        return invertedIndexAVL.find(word.toLowerCase().trim());
    }

    // Print the contents of the inverted index
    public void printInvertedIndex() {
        if (invertedIndexAVL == null) {
            System.out.println("AVL is not initialized.");
            return;
        }

        System.out.println("Inverted Index Contents:");
        invertedIndexAVL.Traverse(); // Traverse and print nodes
    }
    public void displayDataRecursive() {
        if (this.invertedIndexAVL != null) {
           this.invertedIndexAVL.Traverse();
        } else {
           System.out.println("BST is not initialized");
        }
  
     }
  
    // Search using logical operators
    public boolean[] searchWithLogicalOperators(String str) {
        str = str.toLowerCase().trim(); // Normalize input
        System.out.println("Query: " + str);

        if (!str.contains(" or ") && !str.contains(" and ")) {
            // Single term query
            return getDocsForTerm(str);
        } else if (str.contains(" or ") && str.contains(" and ")) {
            // Mixed "AND" and "OR" operations
            String[] ORGroups = str.split(" or ");
            boolean[] result = searchWithAND(ORGroups[0]);

            for (int i = 1; i < ORGroups.length; i++) {
                boolean[] tempResult = searchWithAND(ORGroups[i]);
                result = combineResults(result, tempResult, "OR");
            }
            return result;
        } else if (str.contains(" and ")) {
            // Only "AND" operation
            return searchWithAND(str);
        } else if (str.contains(" or ")) {
            // Only "OR" operation
            return searchWithOR(str);
        }
        return new boolean[50]; // Default to all false if no valid query
    }

    // Handle logical AND queries
    public boolean[] searchWithAND(String str) {
        String[] terms = str.split(" and ");
        boolean[] result = getDocsForTerm(terms[0]); // Get docs for the first term
        System.out.println("Initial AND result for '" + terms[0] + "': ");
        printBooleanArray(result);

        for (int i = 1; i < terms.length; i++) {
            boolean[] tempResult = getDocsForTerm(terms[i]); // Get docs for the next term
            System.out.println("AND result for '" + terms[i] + "': ");
            printBooleanArray(tempResult);
            result = combineResults(result, tempResult, "AND"); // Combine results with AND
        }
        return result;
    }

    // Handle logical OR queries
    public boolean[] searchWithOR(String str) {
        String[] terms = str.split(" or ");
        boolean[] result = getDocsForTerm(terms[0]); // Get docs for the first term
        System.out.println("Initial OR result for '" + terms[0] + "': ");
        printBooleanArray(result);

        for (int i = 1; i < terms.length; i++) {
            boolean[] tempResult = getDocsForTerm(terms[i]); // Get docs for the next term
            System.out.println("OR result for '" + terms[i] + "': ");
            printBooleanArray(tempResult);
            result = combineResults(result, tempResult, "OR"); // Combine results with OR
        }
        return result;
    }

    // Combine results for logical operations
    private boolean[] combineResults(boolean[] r1, boolean[] r2, String operation) {
        boolean[] combined = new boolean[50]; // Assuming 50 documents
        System.out.println("Combining results with operation: " + operation);

        for (int i = 0; i < combined.length; i++) {
            if (operation.equals("AND")) {
                combined[i] = r1[i] && r2[i]; // Intersection of results
            } else if (operation.equals("OR")) {
                combined[i] = r1[i] || r2[i]; // Union of results
            }
        }

        System.out.print("Combined result: ");
        printBooleanArray(combined);
        return combined;
    }

    // Print a boolean array for debugging
    private void printBooleanArray(boolean[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] ? "true" : "false");
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    // Retrieve documents for a specific term
    private boolean[] getDocsForTerm(String term) {
        boolean[] result = new boolean[50]; // Default false for all documents
        System.out.println("Searching for term: " + term);

        if (this.found(term)) {
            result = this.invertedIndexAVL.retrieve().getDocs();
            System.out.print("Docs for term '" + term + "': ");
            printBooleanArray(result);
        } else {
            System.out.println("Term '" + term + "' not found in the inverted index.");
        }
        return result;
    }
}
