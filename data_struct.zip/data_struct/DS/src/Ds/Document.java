/* 
//class represents a document



public class Document {
    int documentID;                 
    LinkedList<String> wordsIndex;   


    public Document() {
        documentID = 0;
        wordsIndex = new LinkedList<String>();
    }


    public void addWord(String word) {
        wordsIndex.insert(word);
    }

  
    public boolean containsWord(String word) {
        if (wordsIndex.empty()) {
            return false; // Index is empty, word cannot be found
        }

        wordsIndex.findFirst(); // Set  to the first element
        for (int i = 0; i < wordsIndex.size; i++) {
            if (wordsIndex.retrieve().compareTo(word) == 0) {
                return true; 
            }
            wordsIndex.findNext(); // Move to the next 
        }
        return false; 
    }
    public boolean found(String word)
    {
        if (wordsIndex.empty())
            return false;

            wordsIndex.findFirst();
        for ( int i = 0 ; i < wordsIndex.size ; i++)
        {
            if ( wordsIndex.retrieve().compareTo(word) == 0)
                return true;
                wordsIndex.findNext();
        }
        return false;
    }
}
*/