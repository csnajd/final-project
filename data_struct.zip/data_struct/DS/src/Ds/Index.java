

package Ds;
public class Index {

    class Document {
        int docID;
        LinkedList<String> index;

        public Document() {
            docID = 0;
            index = new LinkedList<>();
        }

        public void addNew (String word)
        {
            index.insert(word);
        }

        public boolean found(String word)
        {
            if (index.empty())
                return false;
 
            index.findFirst();
            for ( int i = 0 ; i < index.size ; i++)
            {
                if ( index.retrieve().compareTo(word) == 0)
                    return true;
               index.findNext();
            }
            return false;
        }
 }   
    

    Document[] documents;

    public Index() {
        documents = new Document[50];
        for (int i = 0; i < documents.length; i++) {
            documents[i] = new Document();
            documents[i].docID = i;
        }
    }

    public void addWordToDocument(int documentID, String word) {
        documents[documentID].addNew(word);
        
    }

      public void printDocumentContent(int documentID) {
        if (documents[documentID].index.empty()) {
            System.out.println("Empty Document");
        } else {
            documents[documentID].index.findFirst();
            for (int i = 0; i < documents[documentID].index.size; i++) {
                System.out.print(documents[documentID].index.retrieve() + " ");
                documents[documentID].index.findNext();
            }
        }
    }

    public boolean[] getDocs(String str) {
        boolean[] result = new boolean[50];
        for (int i = 0; i < result.length; i++) {
            result[i] = documents[i].found(str);
            
        }
        return result;
    }
    

    public boolean[] searchWithLogicalOperators(String str) {
        str = str.toLowerCase().trim();
        System.out.println("Query: " + str);
    
        if (!str.contains(" or ") && !str.contains(" and ")) {
          
            boolean[] r1 = getDocs(str);
            System.out.print("Single Term Result: ");
          
            return r1;
        } else if (str.contains(" or ") && str.contains(" and ")) {
           
            String[] AND_ORs = str.split(" or ");
            boolean[] r1 = AND_Function(AND_ORs[0]);
            System.out.print("Initial AND/OR Group Result: ");
         
    
            for (int i = 1; i < AND_ORs.length; i++) {
                boolean[] r2 = AND_Function(AND_ORs[i]);
             
                for (int j = 0; j < 50; j++) {
                    r1[j] = r1[j] || r2[j];
                }
                System.out.print("Combined OR Result: ");
             
            }
            return r1;
        } else if (str.contains(" and ")) {
        
            return AND_Function(str);
        } else {
        
            return OR_Function(str);
        }
    }
    public boolean[] AND_Function(String str) {
        String[] ANDs = str.split(" and ");
        boolean[] b1 = getDocs(ANDs[0].trim());
        System.out.print("Initial AND Result for '" + ANDs[0] + "': ");
    
    
        for (int i = 1; i < ANDs.length; i++) {
            boolean[] b2 = getDocs(ANDs[i].trim());
            System.out.print("AND Result for '" + ANDs[i] + "': ");
          
    
            for (int j = 0; j < 50; j++) {
                b1[j] = b1[j] && b2[j];
            }
            System.out.print("Intermediate AND Result: ");
           
        }
        System.out.print("Final AND Result: ");
      
        return b1;
    }
    
    public boolean[] OR_Function(String str) {
        String[] ORs = str.split(" or ");
        boolean[] b1 = getDocs(ORs[0].trim());
        System.out.print("Initial OR Result for '" + ORs[0] + "': ");
      
    
        for (int i = 1; i < ORs.length; i++) {
            boolean[] b2 = getDocs(ORs[i].trim());
            System.out.print("OR Result for '" + ORs[i] + "': ");
           
    
            for (int j = 0; j < 50; j++) {
                b1[j] = b1[j] || b2[j];
            }
            System.out.print("Intermediate OR Result: ");
            
        }
        System.out.print("Final OR Result: ");
     
        return b1;
    }
   
    
}    
    