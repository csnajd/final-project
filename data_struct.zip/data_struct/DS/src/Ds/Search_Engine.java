package Ds;
import java.io.File;
import java.util.Scanner;

public class Search_Engine {
    int tokens = 0;
    int vocab = 0;

    // Data Structures
    Index index;
    IndexRanked indexRanked;
    InvertedIndex keywordIndex;
    RankedInvertedIndex rankedInvertedIndex;
    InvertedIndexAVL invertedIndexAVL;
    InvertedIndexAVLRanked invertedIndexAVLRanked;
    BSTInvertedIndex bstInvertedIndex;
    InvertedIndexBSTRanked bstInvertedIndexRanked;

    // Constructor
    public Search_Engine() {
        index = new Index();
        indexRanked = new IndexRanked(); // Ensure this class exists
        keywordIndex = new InvertedIndex();
        rankedInvertedIndex = new RankedInvertedIndex();
        invertedIndexAVL = new InvertedIndexAVL(); // Ensure this class exists
        invertedIndexAVLRanked = new InvertedIndexAVLRanked(); // Ensure this class exists
        bstInvertedIndex = new BSTInvertedIndex();
        bstInvertedIndexRanked = new InvertedIndexBSTRanked(); // Ensure this class exists
    }
    

    // Load data and process documents
    public void LoadData(String stopFile, String fileName) {
        try {
            // Read the stop words into a single string
            File stopfile = new File(stopFile);
            String stops;
            try (Scanner stopReader = new Scanner(stopfile).useDelimiter("\\Z")) {
                stops = " " + stopReader.next().toLowerCase().replaceAll("[^a-zA-Z0-9]+", " ") + " ";
            }
    
            // Read the documents
            File docsfile = new File(fileName);
            try (Scanner docReader = new Scanner(docsfile)) {
                if (docReader.hasNextLine()) {
                    docReader.nextLine(); // Skip header line
                }
    
                while (docReader.hasNextLine()) {
                    String line = docReader.nextLine().toLowerCase();
    
                    int pos = line.indexOf(',');
                    if (pos == -1) {
                        System.out.println("Invalid line format: " + line);
                        continue;
                    }
    
                    int docID = Integer.parseInt(line.substring(0, pos));
                    String data = line.substring(pos + 1).trim();
                    data = data.replaceAll("[^a-zA-Z0-9']+", " ").trim(); // Clean up the text
    
                    String[] words = data.split(" "); // Split into words
                    for (String word : words) {
                        word = word.trim();
                        if (!word.isEmpty()) {
                            tokens++;
                            // If the word is not a stop word
                            if (!stops.contains(" " + word + " ")) {
                                // Add the word to all data structures
                                index.addWordToDocument(docID, word);
                                keywordIndex.addNew(docID, word);
                                rankedInvertedIndex.addNew(docID, word);
                                invertedIndexAVL.addNew(docID, word);
                                invertedIndexAVLRanked.addNew(docID, word);
                                bstInvertedIndex.addNew(docID, word);
                                bstInvertedIndexRanked.addNew(docID, word);
                            }
                        }
                    }
                }
            }
    
            vocab = invertedIndexAVL.size();
            System.out.println("Tokens: " + tokens);
            System.out.println("Vocabulary: " + vocab);
    
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    // Boolean Retrieval
    public boolean[] Boolean_Retrieval(String query, int DSType) {
        boolean[] docs = new boolean[50];
        System.out.println("=== Boolean Retrieval ===");
        System.out.println("Query: " + query);

        switch (DSType) {
            case 1:
                System.out.println("Using Index List");
                docs = index.searchWithLogicalOperators(query);
                break;
            case 2:
                System.out.println("Using Keyword Index");
                docs = keywordIndex.searchWithLogicalOperators(query);
                break;
            case 3:
                System.out.println("Using BST-based Index");
                docs = bstInvertedIndex.searchWithLogicalOperators(query);
                break;
            case 4:
                System.out.println("Using AVL-based Index");
                docs = invertedIndexAVL.searchWithLogicalOperators(query);
                break;
            default:
                System.out.println("Invalid Data Structure Type.");
        }

        System.out.println("Matching Documents:");
        boolean foundMatch = false;
        for (int i = 0; i < docs.length; i++) {
            if (docs[i]) {
                System.out.println("Document ID: " + i);
                foundMatch = true;
            }
        }

        if (!foundMatch) {
            System.out.println("No matching documents found.");
        }

        return docs;
    }

   
    public void Ranked_Index(String query) {
        System.out.println("=== Ranked Retrieval using Index ===");
        indexRanked.TF(query);
    }

    public void Ranked_RetrievalInvertedIndex(String query) {
        rankedInvertedIndex.calculateTF(query);
    }

    public void Ranked_RetrievalBST(String query) {
        bstInvertedIndexRanked.TF(query);
    }

    public void Ranked_RetrievalAVL(String query) {
        invertedIndexAVLRanked.TF(query);
    }

  
    public void Indexed_Tokens() {
        System.out.println("Tokens and Associated Documents:");
        bstInvertedIndex.displayDataRecursive();
        invertedIndexAVL.displayDataRecursive();
    }


    public void Indexed_Documents() {
        System.out.println("Documents and Word Counts:");
        for (int i = 0; i < 50; i++) {
            System.out.println("Document " + i + ": " + index.documents[i].index.size() + " words.");
        }
    }


    public boolean[] Term_Retrieval(String term, int DSType) {
        boolean[] docs = new boolean[50];
        System.out.println("=== Term Retrieval ===");
        System.out.println("Term: " + term);

        switch (DSType) {
            case 1:
                System.out.println("Using Basic Index");
                docs = index.getDocs(term);
                break;
            case 2:
            System.out.println("Using Keyword Index");
            if (keywordIndex.found(term)) {
                docs = keywordIndex.retrieve().getDocs(); 
            } else {
                System.out.println("Term not found.");
            }
            break;
        
                case 3:
                System.out.println("Using BST-based Index");
                if (bstInvertedIndex.found(term)) {
                    TermTF termData = bstInvertedIndex.invertedIndexBST.retrieve();
                    if (termData != null) {
                        //boolean[] docIDs = termData.getDocs();
                        for (int i = 0; i < docs.length; i++) {
                            docs[i] = docs[i];
                        }
                    } else {
                        System.out.println("Retrieved term data is null.");
                    }
                } else {
                    System.out.println("Term not found in BST-based Index.");
                }
                break;
            
            case 4:
                System.out.println("Using AVL-based Index");
                if (invertedIndexAVL.found(term)) {
                    docs = invertedIndexAVL.invertedIndexAVL.retrieve().getDocs();
                } else {
                    System.out.println("Term not found.");
                }
                break;
            default:
                System.out.println("Invalid Data Structure Type.");
        }

        System.out.println("Matching Documents:");
        boolean foundMatch = false;
        for (int i = 0; i < docs.length; i++) {
            if (docs[i]) {
                System.out.println("Document ID: " + i);
                foundMatch = true;
            }
        }

        if (!foundMatch) {
            System.out.println("No matching documents found.");
        }

        return docs;
    }
}
