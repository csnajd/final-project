package Ds;

import java.util.Arrays;

public class InvertedIndex {
    LinkedList<TermTF> invertedIndex;


    public InvertedIndex() {
        invertedIndex = new LinkedList<TermTF>();
    }


    public int size() {
        return invertedIndex.size();
    }
    public TermTF retrieve() {
        return invertedIndex.retrieve(); // Ensure this points to your internal LinkedList
    }
    
  
    public boolean addNew(int docID, String word) {
        if (invertedIndex.empty()) {
            TermTF newTerm = new TermTF();
            newTerm.setWord(word);
            newTerm.addDocID(docID);
            invertedIndex.insert(newTerm);
            return true;
        } else {
            invertedIndex.findFirst();
            while (!invertedIndex.last()) {
                if (invertedIndex.retrieve().getWord().equals(word)) {
                    TermTF existingTerm = invertedIndex.retrieve();
                    existingTerm.addDocID(docID);
                    invertedIndex.update(existingTerm);
                    return false;
                }
                invertedIndex.findNext();
            }

            if (invertedIndex.retrieve().getWord().equals(word)) {
                TermTF existingTerm = invertedIndex.retrieve();
                existingTerm.addDocID(docID);
                invertedIndex.update(existingTerm);
                return false;
            } else {
                TermTF newTerm = new TermTF();
                newTerm.setWord(word);
                newTerm.addDocID(docID);
                invertedIndex.insert(newTerm);
            }
            return true;
        }
    }

 
    public boolean found(String word) {
        if (invertedIndex.empty()) {
            return false;
        }

        invertedIndex.findFirst();
        for (int i = 0; i < invertedIndex.size(); i++) {
            if (invertedIndex.retrieve().getWord().equals(word)) {
                return true;
            }
            invertedIndex.findNext();
        }
        return false;
    }

    public boolean[] searchWithLogicalOperators(String str) {
        str = str.toLowerCase().trim(); // Normalize input
        System.out.println("Query: " + str);
    
        if (!str.contains(" or ") && !str.contains(" and ")) {
            // Single term search
            return getDocsForTerm(str);
        } else if (str.contains(" or ") && str.contains(" and ")) {
            // Mixed "AND" and "OR" operations
            String[] ORGroups = str.split(" or ");
            boolean[] result = searchWithAND(ORGroups[0]);
            System.out.print("Initial AND group result: ");
            System.out.println(Arrays.toString(result));
    
            for (int i = 1; i < ORGroups.length; i++) {
                boolean[] tempResult = searchWithAND(ORGroups[i]);
                System.out.print("AND group '" + ORGroups[i] + "' result: ");
                System.out.println(Arrays.toString(tempResult));
                result = combineResults(result, tempResult, "OR");
            }
            return result;
        } else if (str.contains(" and ")) {
            // Only "AND" operation
            return searchWithAND(str);
        } else {
            // Only "OR" operation
            return searchWithOR(str);
        }
    }
    public boolean[] searchWithAND(String str) {
        String[] terms = str.split(" and ");
        boolean[] result = getDocsForTerm(terms[0]);
        System.out.print("Initial AND result for '" + terms[0] + "': ");
        System.out.println(Arrays.toString(result));
    
        for (int i = 1; i < terms.length; i++) {
            boolean[] tempResult = getDocsForTerm(terms[i]);
            System.out.print("AND result for '" + terms[i] + "': ");
            System.out.println(Arrays.toString(tempResult));
            result = combineResults(result, tempResult, "AND");
        }
        return result;
    }
    
    public boolean[] searchWithOR(String str) {
        String[] terms = str.split(" or ");
        boolean[] result = getDocsForTerm(terms[0]);
        System.out.print("Initial OR result for '" + terms[0] + "': ");
        System.out.println(Arrays.toString(result));
    
        for (int i = 1; i < terms.length; i++) {
            boolean[] tempResult = getDocsForTerm(terms[i]);
            System.out.print("OR result for '" + terms[i] + "': ");
            System.out.println(Arrays.toString(tempResult));
            result = combineResults(result, tempResult, "OR");
        }
        return result;
    }
   public void printDocument() {
    if (this.invertedIndex.empty()) {
        System.out.println("Empty Inverted Index");
        return;
    }

    System.out.println("Inverted Index Contents:");
    this.invertedIndex.findFirst();
    while (!this.invertedIndex.last()) {
        System.out.println(this.invertedIndex.retrieve());
        this.invertedIndex.findNext();
    }
    System.out.println(this.invertedIndex.retrieve());
}
private boolean[] combineResults(boolean[] r1, boolean[] r2, String operation) {
    boolean[] combined = new boolean[50]; // Assuming 50 documents
    System.out.println("Combining results with operation: " + operation);

    for (int i = 0; i < combined.length; i++) {
        if (operation.equals("AND")) {
            combined[i] = r1[i] && r2[i];
        } else if (operation.equals("OR")) {
            combined[i] = r1[i] || r2[i];
        }
    }

    System.out.println("Combined result: " + Arrays.toString(combined));
    return combined;
}
private boolean[] getDocsForTerm(String term) {
    boolean[] result = new boolean[50]; // Default false for all documents
    System.out.println("Searching for term: " + term);

    if (this.found(term)) {
        result = this.invertedIndex.retrieve().getDocs();
        System.out.println("Docs for term '" + term + "': " + Arrays.toString(result));
    } else {
        System.out.println("Term '" + term + "' not found.");
    }

    return result;
}
} 