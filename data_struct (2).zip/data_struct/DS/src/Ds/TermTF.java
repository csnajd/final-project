package Ds;
public class TermTF {
    String word; 
    boolean[] docIDS; 

 
    public TermTF() {
        docIDS = new boolean [50]; // Assuming 50 documents
        for (int i = 0; i < docIDS.length; i++) {
            docIDS [i] = false; // Initialize frequencies to 0
        }
        word = ""; // Initialize with an empty term
    }

    // Parameterized constructor
    public TermTF(String word, boolean[] docIDS) {
        this.word = word; // Set the word
        this.docIDS = new boolean [docIDS.length];
        for (int i = 0 ; i < docIDS.length ; i++)
            this.docIDS [i] = docIDS[i];

    }
    

    public boolean [] getDocs ()
    {
        boolean [] test = new boolean [docIDS.length];
        for ( int i = 0 ; i < test.length ; i++)
            test[i] = docIDS[i];
        return test;
    }
    public boolean addDocID(int docID) {
        
            if (! docIDS[docID])
            {
                this.docIDS[docID] = true;
                return true;
            }
            return false;
        }

    // Set the word
    public void setWord(String word) {
        this.word = word;
    }

    // Get the word
    public String getWord() {
        return word;
    }

    // Get the document frequencies
   

    // Override toString to display the word and its associated document frequencies
    @Override
    public String toString() {
        String docs = "";
        for (int i = 0, j = 0 ; i < docIDS.length; i++)
            if ( j == 0 && docIDS [i]==true )
            {
                docs += " " + String.valueOf(i) ;
                j++;
            }
            else if ( docIDS [i]==true )
            {
                docs += ", " + String.valueOf(i) ;
                j++;
            }
        
        return word + "[" + docs + ']';
    }
    
     
}
