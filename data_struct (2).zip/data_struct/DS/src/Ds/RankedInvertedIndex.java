package Ds;
public class RankedInvertedIndex {
    class Frequency {
        int docID = 0; // Document ID
        int frequency = 0; // Term frequency
    }

    LinkedList<Keyword> invertedIndex; // LinkedList to store terms
    Frequency[] frequencies; // Array to store frequencies

    // Constructor to initialize the inverted index
    public RankedInvertedIndex() {
        invertedIndex = new LinkedList<Keyword>();
        frequencies = new Frequency[50];
        for (int i = 0; i < frequencies.length; i++) {
            frequencies[i] = new Frequency();
            frequencies[i].docID = i; // Initialize docIDs
        }
    }

    // Get the size of the inverted index
    public int size() {
        return invertedIndex.size();
    }

    // Add a new term or update an existing term
    public boolean addNew(int docID, String word) {
        if (invertedIndex.empty()) {
            Keyword newKeyword = new Keyword();
            newKeyword.setTerm(word);
            newKeyword.addDocument(docID);
            invertedIndex.insert(newKeyword);
            return true;
        } else {
            invertedIndex.findFirst();
            while (!invertedIndex.last()) {
                if (invertedIndex.retrieve().getTerm().equals(word)) {
                    Keyword existingKeyword = invertedIndex.retrieve();
                    existingKeyword.addDocument(docID);
                    invertedIndex.update(existingKeyword);
                    return false;
                }
                invertedIndex.findNext();
            }

            if (invertedIndex.retrieve().getTerm().equals(word)) {
                Keyword existingKeyword = invertedIndex.retrieve();
                existingKeyword.addDocument(docID);
                invertedIndex.update(existingKeyword);
                return false;
            } else {
                Keyword newKeyword = new Keyword();
                newKeyword.setTerm(word);
                newKeyword.addDocument(docID);
                invertedIndex.insert(newKeyword);
            }
            return true;
        }
    }

    // Check if a term exists in the inverted index
    public boolean found(String word) {
        if (invertedIndex.empty()) {
            return false;
        }

        invertedIndex.findFirst();
        for (int i = 0; i < invertedIndex.size(); i++) {
            if (invertedIndex.retrieve().getTerm().equals(word)) {
                return true;
            }
            invertedIndex.findNext();
        }
        return false;
    }

    // Calculate term frequency for a given query
    public void calculateTF(String query) {
        query = query.toLowerCase().trim();
        String[] words = query.split(" ");

        // Reset frequencies
        for (int i = 0; i < frequencies.length; i++) {
            frequencies[i].frequency = 0;
        }

        for (int i = 0; i < words.length; i++) {
            if (found(words[i])) {
                int[] docs = invertedIndex.retrieve().getDocs();
                for (int docID = 0; docID < docs.length; docID++) {
                    frequencies[docID].frequency += docs[docID];
                }
            }
        }

        mergeSort(frequencies, 0, frequencies.length - 1);

        // Print sorted frequencies
        System.out.println("\nDocID\tScore");
        for (int i = 0; i < frequencies.length; i++) {
            if (frequencies[i].frequency > 0) {
                System.out.println(frequencies[i].docID + "\t\t" + frequencies[i].frequency);
            }
        }
    }

    // Merge Sort for frequencies
    private void mergeSort(Frequency[] array, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(array, left, mid);
            mergeSort(array, mid + 1, right);
            merge(array, left, mid, right);
        }
    }

    private void merge(Frequency[] array, int left, int mid, int right) {
        Frequency[] tempArray = new Frequency[right - left + 1];
        int i = left, j = mid + 1, k = 0;

        while (i <= mid && j <= right) {
            if (array[i].frequency >= array[j].frequency) {
                tempArray[k++] = array[i++];
            } else {
                tempArray[k++] = array[j++];
            }
        }

        while (i <= mid) {
            tempArray[k++] = array[i++];
        }

        while (j <= right) {
            tempArray[k++] = array[j++];
        }

        for (k = 0; k < tempArray.length; k++) {
            array[left + k] = tempArray[k];
        }
    }

    // Print the inverted index
    public void printIndex() {
        if (invertedIndex.empty()) {
            System.out.println("Empty Inverted Index");
        } else {
            invertedIndex.findFirst();
            while (!invertedIndex.last()) {
                System.out.println(invertedIndex.retrieve());
                invertedIndex.findNext();
            }
            System.out.println(invertedIndex.retrieve());
        }
    }
}
