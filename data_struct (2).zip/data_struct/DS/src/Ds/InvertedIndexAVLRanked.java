package Ds;
import java.util.function.Function;


@SuppressWarnings("unused")
public class InvertedIndexAVLRanked {
  
        class Frequency {
            int docID = 0;
            int f = 0;
        }
    
        AVLTree<Integer, AVLTree<String, Rank>> AVLrank;
        Frequency[] freqs = new Frequency[50];
    
        public InvertedIndexAVLRanked() {
            AVLrank = new AVLTree<Integer, AVLTree<String, Rank>>();
        }
       
        public boolean addNew(int docID, String word) {
            if (AVLrank.empty()) {
                AVLTree<String, Rank> miniRank = new AVLTree<String, Rank>();
                miniRank.insert(word, new Rank(word, 1));
                AVLrank.insert(docID, miniRank);
                return true;
            } else {
                if (AVLrank.find(docID)) {
                    AVLTree<String, Rank> miniRank = AVLrank.retrieve();
                    if (miniRank.find(word)) {
                        // Document available, word available - increment rank
                        Rank rank = miniRank.retrieve();
                        rank.addRank();
                        miniRank.update(rank);
                        AVLrank.update(miniRank);
                        return false;
                    }
                    // Document available, word unavailable
                    miniRank.insert(word, new Rank(word, 1));
                    AVLrank.update(miniRank);
                    return true;
                }
                // Document unavailable
                AVLTree<String, Rank> miniRank = new AVLTree<String, Rank>();
                miniRank.insert(word, new Rank(word, 1));
                AVLrank.insert(docID, miniRank);
                return true;
            }
        }
    
        public boolean found(int docID, String word) {
            if (AVLrank.find(docID))
                if (AVLrank.retrieve().find(word))
                    return true;
            return false;
        }
    
        public int getRank(int docID, String word) {
            if (AVLrank.find(docID)) {
                if (AVLrank.retrieve().find(word)) {
                    return AVLrank.retrieve().retrieve().getRank();
                }
            }
            return 0;
        }
    
        public void printDocument() {
            AVLrank.TraverseT();
        }
    
        public void TF(String str) {
            str = str.toLowerCase().trim();
            String[] words = str.split(" ");
    
            int index = 0;
            for (int docID = 0; docID < 50; docID++) {
                int count = 0;
                for (int j = 0; j < words.length; j++) {
                    count += this.getRank(docID, words[j]);
                }
                if (count > 0) {
                    freqs[index] = new Frequency();
                    freqs[index].docID = docID;
                    freqs[index].f = count;
                    index++;
                }
            }
    
            mergesort(freqs, 0, index - 1);
    
            for (int x = 0; x < index; x++) {
                System.out.println(freqs[x].docID + "\t\t" + freqs[x].f);
            }
        }
    
        public static void mergesort(Frequency[] A, int l, int r) {
            if (l >= r)
                return;
            int m = (l + r) / 2;
            mergesort(A, l, m); // Sort first half
            mergesort(A, m + 1, r); // Sort second half
            merge(A, l, m, r); // Merge
        }
    
        private static void merge(Frequency[] A, int l, int m, int r) {
            Frequency[] B = new Frequency[r - l + 1];
            int i = l, j = m + 1, k = 0;
    
            while (i <= m && j <= r) {
                if (A[i].f >= A[j].f)
                    B[k++] = A[i++];
                else
                    B[k++] = A[j++];
            }
    
            while (i <= m)
                B[k++] = A[i++];
            while (j <= r)
                B[k++] = A[j++];
    
            for (k = 0; k < B.length; k++)
                A[k + l] = B[k];
        }
    
        public boolean[] AND_OR_Function(String str) {
            if (!str.contains(" OR ") && !str.contains(" AND ")) {
                boolean[] r1 = new boolean[50];
                str = str.toLowerCase().trim();
    
                for (int i = 0; i < r1.length; i++) {
                    r1[i] = (AVLrank.find(i) && AVLrank.retrieve().find(str));
                }
                return r1;
            } else if (str.contains(" OR ") && str.contains(" AND ")) {
                String[] AND_ORs = str.split(" OR ");
                boolean[] r1 = AND_Function(AND_ORs[0]);
    
                for (int i = 1; i < AND_ORs.length; i++) {
                    boolean[] r2 = AND_Function(AND_ORs[i]);
    
                    for (int j = 0; j < 50; j++) {
                        r1[j] = r1[j] || r2[j];
                    }
                }
                return r1;
            } else if (str.contains(" AND ")) {
                return AND_Function(str);
            }
            return OR_Function(str);
        }
        
        public boolean[] AND_Function(String str) {
            String[] ANDs = str.split(" AND ");
            boolean[] b1 = new boolean[50];
    
            for (int i = 0; i < 50; i++) {
                b1[i] = (AVLrank.find(i) && AVLrank.retrieve().find(ANDs[0]));
            }
    
            for (int i = 1; i < ANDs.length; i++) {
                boolean[] b2 = new boolean[50];
    
                for (int j = 0; j < 50; j++) {
                    b2[j] = (AVLrank.find(j) && AVLrank.retrieve().find(ANDs[i]));
                }
    
                for (int j = 0; j < 50; j++) {
                    b1[j] = b1[j] && b2[j];
                }
            }
            return b1;
        }
    
        public boolean[] OR_Function(String str) {
            String[] ORs = str.split(" OR ");
            boolean[] b1 = new boolean[50];
    
            for (int i = 0; i < 50; i++) {
                b1[i] = (AVLrank.find(i) && AVLrank.retrieve().find(ORs[0]));
            }
    
            for (int i = 1; i < ORs.length; i++) {
                boolean[] b2 = new boolean[50];
    
                for (int j = 0; j < 50; j++) {
                    b2[j] = (AVLrank.find(j) && AVLrank.retrieve().find(ORs[i]));
                }
    
                for (int j = 0; j < 50; j++) {
                    b1[j] = b1[j] || b2[j];
                }
            }
            return b1;
        }
    }
    